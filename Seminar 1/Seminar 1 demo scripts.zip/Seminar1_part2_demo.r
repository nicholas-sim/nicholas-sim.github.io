# Seminar 1 Part 2
# R Operations

# Things to Cover

# R as a calculator
# The combine function c()
# Comparison operators
# Data Types
# paste functions

# Vectors (elements must belong to the same type)
# Sequence function "seq()"
# Names of the vector elements, "names()"
# Vector indexing

# Creating a Matrix Using matrix()
# Creating a Matrix Using cbind()

# Referencing elements in a matrix
# Slicing a matrix
# Summarizing a matrix using summary()
# Calculating means using rowMeans(), rowSums(), colMeans(), colSums().
# Recycling property (recycling elements in the shorter vector)



# Exercise 1
# Construct a vector s1 that contains the numbers 3 and 4. Test if s1 is equal to 4. What do you observe?
# Convert the vector s1 to a character vector. Call it s2. Test if s2 is equal to 4. How about equal to "4"?


# Exercise 2
# John, Jim, Jane are 161cm, 174cm, 182cm tall, respectively. 
# Create a vector containing their heights. 
# Name each element in the vector by the names of the individuals. 
# How would you subset the vector to contain only the heights of John and Jim?


