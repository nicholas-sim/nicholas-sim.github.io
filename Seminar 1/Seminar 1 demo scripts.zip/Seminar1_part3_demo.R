# Seminar 1 Part 3
# R Programming

# Things to Cover

# Function
# List
# Flow Controls

# Function
# common functions, rnorm, head, etc

# List
# combining different objects into a list
# Naming the Items in a List

# Flow Controls
# Logical Operators, AND OR NOT
# if, elseif and else 
# ifelse() function
# for loop
# while loop - for iterations
# Writing Our Own Functions


# Exercise 1
# Suppose we want to assign a certain statement to the current weather, measured by degrees Celsius.
# If the temperature is greater than 34 degrees C, we want to print out
# "The weather is very hot. Please stay indoors."
# If the temperature is between 29 and and 34 degrees C, we want to print out
# "The weather is hot. Please use sunscreen if you need to be outdoors."
# If the temperature is less than 29 degrees C, we want to print out 
# "The weather is relatively mild."


#Exercise 2
# Mary has two children - Joaqium and Elizabeth. Let's construct a vector, called mary.children, 
# that records their gender, where its first element is B and the second element is G.

# mary.children <- c('B', 'G')

# Let's do the following using if, else if and else statements.

# If Mary has no daughters, print out
# "Mary's children are both boys."
# If Mary has one daughter, print out
# "Mary has one girl and one boy."
# If Mary has two daughters, print out
# "Mary's children are both girls."
